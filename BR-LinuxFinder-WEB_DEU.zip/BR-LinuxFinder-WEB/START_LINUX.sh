#!/usr/bin/env bash
xdg-open "$(dirname "$0")/index.html" >/dev/null 2>&1 &
