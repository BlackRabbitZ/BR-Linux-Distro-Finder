const APP_DATA = {
  "APP_TITLE": "BlackRabbitZ Linux Distributions-Finder",
  "COLORS": {
    "bg": "#0b0c0f",
    "panel": "#111216",
    "panel2": "#17181d",
    "card": "#0f1014",
    "border": "#2d3038",
    "red": "#ff2436",
    "red2": "#b61726",
    "line": "#7f141d",
    "text": "#f1f1f1",
    "muted": "#b9bcc4",
    "soft": "#858a94",
    "select": "#20222a"
  },
  "DISTROS": {
    "Linux Mint": [
      "beginner",
      "daily",
      "office",
      "stable",
      "windows_like",
      "low",
      "laptop"
    ],
    "Ubuntu": [
      "beginner",
      "daily",
      "office",
      "dev",
      "support",
      "server",
      "gnome"
    ],
    "Kubuntu": [
      "beginner",
      "daily",
      "office",
      "kde",
      "windows_like"
    ],
    "Xubuntu": [
      "beginner",
      "daily",
      "office",
      "xfce",
      "low",
      "old_hw"
    ],
    "Lubuntu": [
      "beginner",
      "daily",
      "office",
      "lxqt",
      "very_low",
      "old_hw"
    ],
    "Zorin OS": [
      "beginner",
      "daily",
      "office",
      "modern",
      "windows_like"
    ],
    "elementary OS": [
      "beginner",
      "daily",
      "office",
      "modern",
      "mac_like"
    ],
    "Pop!_OS": [
      "beginner",
      "daily",
      "dev",
      "gaming",
      "nvidia",
      "modern",
      "laptop"
    ],
    "KDE neon": [
      "daily",
      "office",
      "kde",
      "modern"
    ],
    "MX Linux": [
      "beginner",
      "daily",
      "stable",
      "low",
      "old_hw"
    ],
    "Peppermint OS": [
      "beginner",
      "daily",
      "low",
      "old_hw"
    ],
    "PCLinuxOS": [
      "beginner",
      "daily",
      "office",
      "stable"
    ],
    "TUXEDO OS": [
      "beginner",
      "daily",
      "office",
      "kde",
      "laptop",
      "gaming"
    ],
    "Solus": [
      "daily",
      "office",
      "modern",
      "gaming"
    ],
    "Nobara Linux": [
      "gaming",
      "steam",
      "proton",
      "aaa",
      "nvidia",
      "amd_gpu",
      "performance",
      "beginner",
      "current"
    ],
    "Bazzite": [
      "gaming",
      "steam",
      "proton",
      "console",
      "aaa",
      "nvidia",
      "amd_gpu",
      "immutable",
      "beginner"
    ],
    "ChimeraOS": [
      "gaming",
      "steam",
      "console",
      "amd_gpu",
      "proton"
    ],
    "Drauger OS": [
      "gaming",
      "performance",
      "aaa",
      "nvidia",
      "amd_gpu"
    ],
    "Garuda Linux": [
      "gaming",
      "arch",
      "performance",
      "kde",
      "rolling",
      "current"
    ],
    "CachyOS": [
      "gaming",
      "arch",
      "performance",
      "rolling",
      "current"
    ],
    "Regata OS": [
      "gaming",
      "steam",
      "kde",
      "beginner"
    ],
    "SteamOS": [
      "gaming",
      "steam",
      "console",
      "amd_gpu"
    ],
    "Fedora Games Spin": [
      "gaming",
      "current",
      "fedora"
    ],
    "Fedora Workstation": [
      "dev",
      "ai",
      "docker",
      "current",
      "gnome",
      "modern"
    ],
    "Fedora KDE Spin": [
      "dev",
      "current",
      "kde",
      "modern"
    ],
    "Debian": [
      "stable",
      "server",
      "daily",
      "office",
      "privacy",
      "dev",
      "low"
    ],
    "openSUSE Leap": [
      "stable",
      "server",
      "office",
      "kde"
    ],
    "openSUSE Tumbleweed": [
      "dev",
      "rolling",
      "current",
      "kde",
      "docker"
    ],
    "EndeavourOS": [
      "arch",
      "advanced",
      "rolling",
      "current",
      "dev",
      "gaming"
    ],
    "Arch Linux": [
      "expert",
      "arch",
      "rolling",
      "current",
      "control",
      "dev"
    ],
    "Manjaro": [
      "arch",
      "beginner",
      "current",
      "gaming",
      "daily"
    ],
    "NixOS": [
      "advanced",
      "dev",
      "docker",
      "reproducible",
      "security"
    ],
    "Void Linux": [
      "advanced",
      "control",
      "low",
      "dev"
    ],
    "Gentoo": [
      "expert",
      "control",
      "source",
      "dev"
    ],
    "Kali Linux": [
      "pentest",
      "ethical_hacking",
      "security",
      "tools",
      "wifi",
      "web_pentest",
      "network_pentest",
      "forensics",
      "advanced"
    ],
    "Parrot OS": [
      "pentest",
      "ethical_hacking",
      "security",
      "privacy",
      "tools",
      "web_pentest",
      "osint",
      "beginner"
    ],
    "BlackArch Linux": [
      "pentest",
      "ethical_hacking",
      "security",
      "arch",
      "expert",
      "tools",
      "exploit",
      "reverse"
    ],
    "BackBox Linux": [
      "pentest",
      "ethical_hacking",
      "security",
      "tools",
      "beginner",
      "web_pentest"
    ],
    "Pentoo": [
      "pentest",
      "security",
      "wifi",
      "forensics",
      "advanced"
    ],
    "ArchStrike": [
      "pentest",
      "arch",
      "security",
      "advanced"
    ],
    "SamuraiWTF": [
      "pentest",
      "web_pentest",
      "security",
      "tools"
    ],
    "NST Linux": [
      "pentest",
      "network_pentest",
      "security",
      "forensics"
    ],
    "CAINE": [
      "security",
      "forensics",
      "pentest"
    ],
    "REMnux": [
      "security",
      "malware",
      "reverse",
      "forensics"
    ],
    "Security Onion": [
      "security",
      "blue_team",
      "monitoring",
      "server"
    ],
    "SELKS": [
      "security",
      "blue_team",
      "monitoring",
      "server"
    ],
    "Tails": [
      "privacy",
      "anonymity",
      "tor",
      "live_usb",
      "security"
    ],
    "Qubes OS": [
      "privacy",
      "security",
      "compartment",
      "advanced",
      "vm",
      "isolation"
    ],
    "Whonix": [
      "privacy",
      "anonymity",
      "tor",
      "vm",
      "security"
    ],
    "Kodachi Linux": [
      "privacy",
      "anonymity",
      "tor",
      "live_usb"
    ],
    "Septor Linux": [
      "privacy",
      "anonymity",
      "tor",
      "daily"
    ],
    "PureOS": [
      "privacy",
      "daily",
      "office",
      "security"
    ],
    "Heads": [
      "privacy",
      "security",
      "expert",
      "live_usb"
    ],
    "Alpine Linux": [
      "security",
      "server",
      "low",
      "advanced"
    ],
    "Ubuntu Server": [
      "server",
      "stable",
      "support",
      "docker"
    ],
    "Rocky Linux": [
      "server",
      "stable",
      "enterprise"
    ],
    "AlmaLinux": [
      "server",
      "stable",
      "enterprise"
    ],
    "Oracle Linux": [
      "server",
      "stable",
      "enterprise"
    ],
    "Fedora Server": [
      "server",
      "current",
      "docker"
    ],
    "antiX": [
      "very_low",
      "old_hw",
      "privacy",
      "daily"
    ],
    "Puppy Linux": [
      "very_low",
      "old_hw",
      "live_usb"
    ],
    "Bodhi Linux": [
      "very_low",
      "old_hw",
      "daily"
    ],
    "Tiny Core Linux": [
      "very_low",
      "old_hw",
      "expert"
    ],
    "LXLE": [
      "low",
      "old_hw",
      "daily"
    ],
    "SparkyLinux": [
      "low",
      "old_hw",
      "daily"
    ]
  },
  "RADIO_QUESTIONS": [
    [
      "main_use",
      "Was ist dein Hauptziel mit Linux?",
      [
        [
          "daily",
          "Alltag / Internet / Medien"
        ],
        [
          "office",
          "Büro / Office / Schule / Studium"
        ],
        [
          "gaming",
          "Gaming"
        ],
        [
          "dev",
          "Programmierung / Entwicklung"
        ],
        [
          "ethical_hacking",
          "Ethical Hacking lernen"
        ],
        [
          "pentest",
          "Pentesting / Security-Tools"
        ],
        [
          "security",
          "Cybersecurity / Analyse / Verteidigung"
        ],
        [
          "privacy",
          "Datenschutz / Privatsphäre"
        ],
        [
          "anonymity",
          "Anonymität / Tor / Live-System"
        ],
        [
          "server",
          "Server / Hosting / Homeserver"
        ],
        [
          "old_hw",
          "Alte oder schwache Hardware"
        ]
      ]
    ],
    [
      "install_target",
      "Wie willst du Linux einsetzen?",
      [
        [
          "linux_only",
          "Als Hauptsystem"
        ],
        [
          "dual",
          "Neben Windows im Dual-Boot"
        ],
        [
          "test",
          "Erstmal testen"
        ],
        [
          "vm",
          "In einer virtuellen Maschine"
        ],
        [
          "live_usb",
          "Als Live-USB-Stick"
        ]
      ]
    ],
    [
      "device",
      "Auf welchem Gerät soll Linux laufen?",
      [
        [
          "desktop",
          "Desktop-PC"
        ],
        [
          "laptop",
          "Laptop"
        ],
        [
          "mini_pc",
          "Mini-PC / NUC"
        ],
        [
          "arm",
          "ARM-Gerät / Raspberry Pi / Apple Silicon"
        ],
        [
          "server_hw",
          "Server-Hardware"
        ]
      ]
    ],
    [
      "experience",
      "Wie viel Erfahrung hast du mit Linux?",
      [
        [
          "beginner",
          "Anfänger / noch nie benutzt"
        ],
        [
          "some",
          "Grundkenntnisse"
        ],
        [
          "advanced",
          "Fortgeschritten"
        ],
        [
          "expert",
          "Experte / Power User"
        ]
      ]
    ],
    [
      "install_effort",
      "Wie aufwendig darf Installation und Einrichtung sein?",
      [
        [
          "easy",
          "Sehr einfach"
        ],
        [
          "medium_setup",
          "Etwas Einrichtung ist okay"
        ],
        [
          "hard",
          "Komplex ist okay"
        ]
      ]
    ],
    [
      "maintenance",
      "Wie viel Wartung willst du langfristig übernehmen?",
      [
        [
          "low_maintenance",
          "Möglichst wenig Wartung"
        ],
        [
          "normal_maintenance",
          "Normale Updates sind okay"
        ],
        [
          "manual_control",
          "Ich will viel selbst kontrollieren"
        ]
      ]
    ],
    [
      "updates",
      "Was bevorzugst du bei Updates und Paketen?",
      [
        [
          "stable",
          "Maximale Stabilität / konservative Pakete"
        ],
        [
          "balanced",
          "Gute Balance"
        ],
        [
          "current",
          "Aktuelle Pakete"
        ],
        [
          "rolling",
          "Rolling Release / immer sehr aktuell"
        ]
      ]
    ],
    [
      "cpu",
      "Welche CPU nutzt du?",
      [
        [
          "intel",
          "Intel x86_64"
        ],
        [
          "amd",
          "AMD x86_64"
        ],
        [
          "arm",
          "ARM / Raspberry Pi / Apple Silicon"
        ]
      ]
    ],
    [
      "gpu",
      "Welche Grafikkarte nutzt du?",
      [
        [
          "nvidia",
          "NVIDIA"
        ],
        [
          "amd_gpu",
          "AMD Radeon"
        ],
        [
          "intel_gpu",
          "Intel Graphics"
        ],
        [
          "none",
          "Keine dedizierte Grafikkarte"
        ]
      ]
    ],
    [
      "ram",
      "Wie viel Arbeitsspeicher hast du?",
      [
        [
          "very_low",
          "Unter 4 GB"
        ],
        [
          "low",
          "4 bis 8 GB"
        ],
        [
          "mid",
          "8 bis 16 GB"
        ],
        [
          "high",
          "16 bis 32 GB"
        ],
        [
          "very_high",
          "32 GB oder mehr"
        ]
      ]
    ],
    [
      "storage",
      "Wie viel Speicherplatz willst du für Linux nutzen?",
      [
        [
          "tiny",
          "Unter 32 GB"
        ],
        [
          "small",
          "32 bis 64 GB"
        ],
        [
          "medium_storage",
          "128 bis 256 GB"
        ],
        [
          "large",
          "Mehr als 256 GB"
        ]
      ]
    ],
    [
      "hardware_age",
      "Wie stark ist dein Gerät insgesamt?",
      [
        [
          "new",
          "Neue / starke Hardware"
        ],
        [
          "normal",
          "Normale Hardware"
        ],
        [
          "old_hw",
          "Ältere Hardware"
        ],
        [
          "very_low",
          "Sehr schwache Hardware"
        ]
      ]
    ],
    [
      "battery",
      "Ist Laptop-Akkulaufzeit wichtig?",
      [
        [
          "battery_yes",
          "Ja, sehr wichtig"
        ],
        [
          "battery_some",
          "Teilweise"
        ],
        [
          "battery_no",
          "Nein"
        ]
      ]
    ],
    [
      "desktop_env",
      "Welche Oberfläche passt am besten zu dir?",
      [
        [
          "windows_like",
          "Windows-ähnlich"
        ],
        [
          "kde",
          "KDE Plasma / modern anpassbar"
        ],
        [
          "gnome",
          "GNOME / modern und schlicht"
        ],
        [
          "xfce",
          "XFCE / leichtgewichtig"
        ],
        [
          "mac_like",
          "MacOS-ähnlich"
        ],
        [
          "minimal",
          "Minimalistisch"
        ]
      ]
    ],
    [
      "office_use",
      "Welche Office-/Alltagsnutzung ist wichtig?",
      [
        [
          "private",
          "Privat / Alltag"
        ],
        [
          "school",
          "Schule / Studium"
        ],
        [
          "business",
          "Business / Homeoffice"
        ],
        [
          "documents",
          "Dokumente, Tabellen, Präsentationen"
        ]
      ]
    ],
    [
      "privacy_level",
      "Wie wichtig sind Datenschutz und Privatsphäre?",
      [
        [
          "normal_privacy",
          "Normal"
        ],
        [
          "privacy",
          "Hoch"
        ],
        [
          "privacy_strict",
          "Sehr hoch / möglichst wenig Datenspuren"
        ]
      ]
    ],
    [
      "anonymity_level",
      "Brauchst du Anonymität im Internet?",
      [
        [
          "no_anonymity",
          "Nein"
        ],
        [
          "tor_optional",
          "Teilweise mit Tor"
        ],
        [
          "anonymity",
          "Ja, Anonymität ist ein Hauptziel"
        ],
        [
          "live_anonymity",
          "Maximal als Live-System"
        ]
      ]
    ],
    [
      "security_level",
      "Wie hoch soll das Sicherheitsniveau sein?",
      [
        [
          "standard",
          "Standard für Alltag"
        ],
        [
          "security",
          "Hoch"
        ],
        [
          "hardened",
          "Sehr hoch / gehärtet"
        ],
        [
          "compartment",
          "Isolation / getrennte Bereiche / Qubes-Ansatz"
        ]
      ]
    ],
    [
      "gaming_type",
      "Welche Gaming-Richtung passt am besten?",
      [
        [
          "no_gaming",
          "Kein Gaming"
        ],
        [
          "steam",
          "Steam / Proton"
        ],
        [
          "aaa",
          "AAA-Spiele"
        ],
        [
          "competitive",
          "Competitive Games"
        ],
        [
          "retro",
          "Retro / Emulatoren"
        ],
        [
          "console",
          "Konsolen-artiges System"
        ],
        [
          "casual",
          "Gelegentliches Gaming"
        ]
      ]
    ],
    [
      "anticheat",
      "Sind dir Anti-Cheat-Spiele wichtig?",
      [
        [
          "no_anticheat",
          "Nein"
        ],
        [
          "partly",
          "Teilweise"
        ],
        [
          "yes",
          "Ja, sehr wichtig"
        ]
      ]
    ],
    [
      "server_use",
      "Willst du Linux als Server nutzen?",
      [
        [
          "no_server",
          "Nein"
        ],
        [
          "homeserver",
          "Homeserver"
        ],
        [
          "professional_server",
          "Professioneller Server"
        ],
        [
          "docker",
          "Docker / Container / DevOps"
        ]
      ]
    ],
    [
      "virtualization",
      "Brauchst du Virtualisierung oder Container?",
      [
        [
          "no_vm",
          "Nein"
        ],
        [
          "docker",
          "Docker / Container"
        ],
        [
          "vm",
          "Virtuelle Maschinen"
        ],
        [
          "isolation",
          "Starke Isolation / Sandboxing"
        ]
      ]
    ]
  ],
  "CHECK_QUESTIONS": [
    [
      "gaming_extra",
      "Gaming: Was brauchst du konkret?",
      [
        [
          "no_gaming",
          "Kein Gaming"
        ],
        [
          "steam",
          "Steam"
        ],
        [
          "proton",
          "Proton / Windows-Spiele"
        ],
        [
          "aaa",
          "AAA-Games"
        ],
        [
          "competitive",
          "Competitive Games"
        ],
        [
          "retro",
          "Retro / Emulatoren"
        ],
        [
          "minecraft",
          "Minecraft"
        ],
        [
          "performance",
          "Maximale Performance"
        ]
      ]
    ],
    [
      "pentest_extra",
      "Pentesting / Ethical Hacking: Welche Bereiche?",
      [
        [
          "no_pentest",
          "NICHTS"
        ],
        [
          "wifi",
          "WLAN-Sicherheit"
        ],
        [
          "web_pentest",
          "Web-Pentesting"
        ],
        [
          "network_pentest",
          "Netzwerk-Pentesting"
        ],
        [
          "reverse",
          "Reverse Engineering"
        ],
        [
          "malware",
          "Malware-Analyse"
        ],
        [
          "exploit",
          "Exploit Development"
        ],
        [
          "forensics",
          "Forensik"
        ],
        [
          "red_team",
          "Red Teaming"
        ],
        [
          "blue_team",
          "Blue Teaming"
        ],
        [
          "osint",
          "OSINT"
        ]
      ]
    ],
    [
      "dev_extra",
      "Programmierung / Entwicklung: Was machst du?",
      [
        [
          "no_dev",
          "Keine"
        ],
        [
          "python",
          "Python"
        ],
        [
          "webdev",
          "Webentwicklung"
        ],
        [
          "cpp",
          "C / C++"
        ],
        [
          "rust",
          "Rust"
        ],
        [
          "java",
          "Java"
        ],
        [
          "ai",
          "KI / AI / Machine Learning"
        ],
        [
          "docker",
          "Docker / DevOps"
        ],
        [
          "android",
          "Android"
        ]
      ]
    ],
    [
      "office_extra",
      "Büro / Alltag: Was ist wichtig?",
      [
        [
          "no_office_extra",
          "Keine Angabe"
        ],
        [
          "office",
          "Office"
        ],
        [
          "daily",
          "Internet / Alltag"
        ],
        [
          "multimedia",
          "Multimedia"
        ],
        [
          "printer",
          "Drucker / Scanner"
        ],
        [
          "support",
          "Große Community"
        ],
        [
          "laptop",
          "Laptop-Akku"
        ]
      ]
    ]
  ],
  "TAG_ALIASES": {
    "some": "beginner",
    "easy": "beginner",
    "medium_setup": "beginner",
    "hard": "advanced",
    "low_maintenance": "stable",
    "normal_maintenance": "balanced",
    "manual_control": "control",
    "balanced": "current",
    "dual": "beginner",
    "test": "live_usb",
    "linux_only": "daily",
    "mini_pc": "daily",
    "server_hw": "server",
    "battery_yes": "laptop",
    "battery_some": "laptop",
    "battery_no": "daily",
    "private": "office",
    "school": "office",
    "business": "office",
    "documents": "office",
    "normal_privacy": "daily",
    "no_anonymity": "daily",
    "standard": "daily",
    "new": "current",
    "normal": "daily",
    "tiny": "very_low",
    "small": "low",
    "medium_storage": "daily",
    "large": "daily",
    "very_high": "performance",
    "mid": "daily",
    "high": "performance",
    "intel_gpu": "daily",
    "none": "daily",
    "arm": "advanced",
    "privacy_strict": "privacy",
    "tor_optional": "tor",
    "live_anonymity": "live_usb",
    "hardened": "security",
    "compartment": "isolation",
    "yes": "gaming",
    "partly": "gaming",
    "no_anticheat": "daily",
    "casual": "gaming",
    "no_gaming": "daily",
    "no_server": "daily",
    "homeserver": "server",
    "professional_server": "server",
    "no_vm": "daily",
    "no_pentest": "daily",
    "no_dev": "daily",
    "no_office_extra": "daily"
  },
  "WARNINGS": {
    "Qubes OS": "Qubes OS braucht starke Hardware, Virtualisierung und ist eher für Fortgeschrittene geeignet.",
    "Tails": "Tails ist für Live-USB und Anonymität gedacht, nicht als normales Alltagssystem.",
    "Kali Linux": "Kali ist primär für Pentesting gedacht und nicht ideal als normales Alltagssystem.",
    "BlackArch Linux": "BlackArch ist sehr umfangreich und eher für erfahrene Nutzer.",
    "SteamOS": "SteamOS ist stark auf Gaming/Steam-Deck-artige Nutzung ausgelegt."
  }
};
