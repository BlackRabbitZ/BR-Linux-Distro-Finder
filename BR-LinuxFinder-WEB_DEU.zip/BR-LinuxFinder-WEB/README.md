# BlackRabbitZ Linux Finder Web-App

Diese Version ist eine lokale Web-App aus dem Python/Tkinter-Skript.

## Start

- `index.html` doppelt anklicken
- Der Standardbrowser öffnet die App direkt lokal
- Kein Webserver nötig
- Keine Installation nötig

## Funktionen

- kompletter Fragenkatalog
- Radio- und Checkbox-Fragen
- gleiche Scoring-/Auswertungslogik wie im Python-Skript
- Top-10-Empfehlungen
- Hinweise/Warnungen
- Distributionen anzeigen
- Ergebnis als TXT speichern
- Ergebnis als JSON speichern
- Zurücksetzen
- About-Me mit Discord-Link
- lokale Speicherung der Auswahl im Browser


## Logo anzeigen
Lege dein Bild **logo.png** in denselben Ordner wie `index.html`.
Die Web-App lädt es automatisch im Header. Der Dateiname muss exakt `logo.png` heißen.
