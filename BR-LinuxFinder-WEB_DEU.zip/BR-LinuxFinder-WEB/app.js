
const $ = (sel, el=document) => el.querySelector(sel);
const $$ = (sel, el=document) => Array.from(el.querySelectorAll(sel));
const {DISTROS, RADIO_QUESTIONS, CHECK_QUESTIONS, TAG_ALIASES, WARNINGS} = APP_DATA;
const state = { radios:{}, checks:{} };
function esc(s){return String(s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function buildQuestions(){
  const box = $('#questions'); box.innerHTML=''; let n=1;
  RADIO_QUESTIONS.forEach(([key,title,opts])=>{
    state.radios[key]=opts[0][0];
    const div=document.createElement('div'); div.className='qblock'; div.dataset.text=(title+' '+opts.map(o=>o[1]).join(' ')).toLowerCase();
    div.innerHTML=`<div class="qtitle"><span class="badge">${n}</span><span>${esc(title)}</span></div><div class="options"></div>`;
    const optbox=$('.options',div);
    opts.forEach(([val,label],idx)=>{
      const id=`r_${key}_${val}`;
      optbox.insertAdjacentHTML('beforeend',`<label class="option" for="${id}"><input id="${id}" type="radio" name="${key}" value="${esc(val)}" ${idx===0?'checked':''}> <span>${esc(label)}</span></label>`);
    });
    box.appendChild(div); n++;
  });
  CHECK_QUESTIONS.forEach(([key,title,opts])=>{
    state.checks[key]={};
    const div=document.createElement('div'); div.className='qblock'; div.dataset.text=(title+' '+opts.map(o=>o[1]).join(' ')).toLowerCase();
    div.innerHTML=`<div class="qtitle"><span class="badge">${n}</span><span>${esc(title)}</span></div><div class="options"></div>`;
    const optbox=$('.options',div);
    opts.forEach(([val,label])=>{
      state.checks[key][val]=false; const id=`c_${key}_${val}`;
      optbox.insertAdjacentHTML('beforeend',`<label class="option" for="${id}"><input id="${id}" type="checkbox" data-group="${key}" value="${esc(val)}"> <span>${esc(label)}</span></label>`);
    });
    box.appendChild(div); n++;
  });
  box.addEventListener('change', e=>{
    if(e.target.type==='radio') state.radios[e.target.name]=e.target.value;
    if(e.target.type==='checkbox') state.checks[e.target.dataset.group][e.target.value]=e.target.checked;
    saveLocal();
  });
  loadLocal();
}
function selectedTags(){
  let tags=[];
  Object.values(state.radios).forEach(val=>{tags.push(val); tags.push(TAG_ALIASES[val] || val);});
  Object.values(state.checks).forEach(group=>Object.entries(group).forEach(([tag,on])=>{ if(on){tags.push(tag); tags.push(TAG_ALIASES[tag] || tag);}}));
  const main_use=state.radios.main_use || 'daily';
  const experience=state.radios.experience || 'beginner';
  const ram=state.radios.ram || 'mid';
  const install_target=state.radios.install_target || 'linux_only';
  if(experience==='beginner') tags.push('beginner','easy','support');
  if(experience==='expert') tags.push('expert','control','advanced');
  if(['privacy','anonymity'].includes(main_use)) tags.push('privacy','security');
  if(['anonymity','live_anonymity'].includes(state.radios.anonymity_level || 'no_anonymity')) tags.push('anonymity','tor','privacy');
  if((state.radios.privacy_level || 'normal_privacy')==='privacy_strict') tags.push('privacy','security');
  if((state.radios.security_level || 'standard')==='compartment' || (state.radios.virtualization || 'no_vm')==='isolation') tags.push('compartment','isolation','security','privacy','vm');
  if(['very_low','low'].includes(ram)) tags.push('low','very_low','old_hw');
  if(['high','very_high'].includes(ram)) tags.push('performance','vm');
  if(install_target==='live_usb') tags.push('live_usb','privacy');
  if((state.radios.gaming_type || 'no_gaming')==='no_gaming' && main_use !== 'gaming'){
    const banned=['gaming','steam','proton','aaa','competitive','retro','console','minecraft'];
    tags=tags.filter(t=>!banned.includes(t));
  }
  return tags;
}
function evaluate(){
  const tags=selectedTags(); const scores=[];
  Object.entries(DISTROS).forEach(([name,dtags])=>{
    let score=0; const reasons=[];
    tags.forEach(t=>{ if(dtags.includes(t)){ score+=3; if(!reasons.includes(t)) reasons.push(t); }});
    if(state.radios.experience==='beginner' && dtags.some(x=>['expert','advanced'].includes(x))) score-=5;
    if(['daily','office'].includes(state.radios.main_use) && dtags.includes('pentest')) score-=4;
    if(state.radios.main_use==='gaming' && !dtags.includes('gaming')) score-=3;
    if(state.radios.main_use==='pentest' && !dtags.includes('pentest')) score-=3;
    if(state.radios.main_use==='anonymity' && !dtags.includes('anonymity')) score-=2;
    if((state.radios.gaming_type || 'no_gaming')==='no_gaming' && state.radios.main_use!=='gaming' && dtags.includes('gaming')) score-=5;
    if((state.radios.install_target || 'linux_only')==='vm' && dtags.includes('live_usb')) score-=3;
    if(state.radios.ram==='very_low' && dtags.some(x=>['vm','compartment','gnome'].includes(x))) score-=6;
    if(state.radios.gpu==='nvidia' && dtags.includes('nvidia')) score+=4;
    if(state.radios.gpu==='amd_gpu' && dtags.includes('amd_gpu')) score+=4;
    if(score>0) scores.push({score,name,reasons,dtags});
  });
  scores.sort((a,b)=>b.score-a.score); const top=scores.slice(0,10);
  let out='BLACKRABBITZ LINUX FINDER - AUSWERTUNG\n\nTop-Empfehlungen:\n\n';
  top.forEach((r,i)=>{
    out += `${String(i+1).padStart(2,'0')}. ${r.name}  | Score: ${r.score}\n`;
    out += `    Passt wegen: ${r.reasons.length?r.reasons.slice(0,8).join(', '):'allgemeine Übereinstimmung'}\n`;
    out += `    Kategorie-Tags: ${r.dtags.slice(0,12).join(', ')}\n`;
    if(WARNINGS[r.name]) out += `    Hinweis: ${WARNINGS[r.name]}\n`;
    out += '\n';
  });
  out += '\nAusgewählte Antworten:\n';
  RADIO_QUESTIONS.forEach(([key,title,opts])=>{
    const val=state.radios[key]; const found=opts.find(o=>o[0]===val); out+=`- ${title} ${found?found[1]:val}\n`;
  });
  const checked=[];
  CHECK_QUESTIONS.forEach(([key,title,opts])=>{
    const vals=opts.filter(([val])=>state.checks[key]?.[val]).map(([,label])=>label);
    if(vals.length) checked.push(`- ${title} ${vals.join(', ')}`);
  });
  if(checked.length) out += '\nMehrfachauswahl:\n'+checked.join('\n');
  $('#output').textContent=out;
  renderCards(top);
}
function renderCards(top){
  const html = top.slice(0,3).map((r,i)=>`<div class="topResult"><b>${i+1}. ${esc(r.name)}</b> <span class="score">Score: ${r.score}</span><br><span class="small">${esc(r.reasons.slice(0,8).join(', '))}</span>${WARNINGS[r.name]?`<br><span class="small">Hinweis: ${esc(WARNINGS[r.name])}</span>`:''}</div>`).join('');
  $('#cards').innerHTML=html;
}
function showDistros(){
 const grouped={"Gaming":[],"Pentesting / Ethical Hacking":[],"Datenschutz / Anonymität":[],"Office / Alltag":[],"Server":[],"Alte Hardware":[],"Entwicklung":[],"Sonstige":[]};
 Object.entries(DISTROS).forEach(([n,t])=>{
   if(t.includes('gaming')) grouped['Gaming'].push(n);
   else if(t.includes('pentest')||t.includes('ethical_hacking')) grouped['Pentesting / Ethical Hacking'].push(n);
   else if(t.includes('privacy')||t.includes('anonymity')) grouped['Datenschutz / Anonymität'].push(n);
   else if(t.includes('server')) grouped['Server'].push(n);
   else if(t.includes('old_hw')||t.includes('very_low')) grouped['Alte Hardware'].push(n);
   else if(t.includes('dev')) grouped['Entwicklung'].push(n);
   else if(t.includes('daily')||t.includes('office')) grouped['Office / Alltag'].push(n);
   else grouped['Sonstige'].push(n);
 });
 let lines=`Enthaltene Distributionen: ${Object.keys(DISTROS).length}\n\n`;
 Object.entries(grouped).forEach(([g,items])=>{ if(items.length){ lines+=g+':\n'; items.sort().forEach(x=>lines+='  - '+x+'\n'); lines+='\n'; }});
 $('#output').textContent=lines; $('#cards').innerHTML='';
}
function resetAll(){
 RADIO_QUESTIONS.forEach(([key,,opts])=>{state.radios[key]=opts[0][0]; const el=$(`input[name="${key}"][value="${CSS.escape(opts[0][0])}"]`); if(el) el.checked=true;});
 CHECK_QUESTIONS.forEach(([key,,opts])=>opts.forEach(([val])=>{state.checks[key][val]=false; const el=$(`#c_${CSS.escape(key)}_${CSS.escape(val)}`); if(el) el.checked=false;}));
 $('#output').textContent='Noch keine Auswertung.\n\nBeantworte die Fragen links und klicke auf AUSWERTEN.'; $('#cards').innerHTML=''; saveLocal();
}
function saveResult(kind='txt'){
 const text=$('#output').textContent.trim(); if(!text) return;
 let blob, name;
 if(kind==='json'){
   const data={created:new Date().toISOString(), result:text, answers:state.radios, checks:state.checks};
   blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); name='blackrabbitz_linux_finder_ergebnis.json';
 }else{ blob=new Blob([text],{type:'text/plain;charset=utf-8'}); name='blackrabbitz_linux_finder_ergebnis.txt'; }
 const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function saveLocal(){ localStorage.setItem('brz-linux-finder-state', JSON.stringify(state)); }
function loadLocal(){
 try{ const saved=JSON.parse(localStorage.getItem('brz-linux-finder-state')||'null'); if(!saved) return;
   Object.assign(state.radios, saved.radios||{}); Object.assign(state.checks, saved.checks||{});
   Object.entries(state.radios).forEach(([k,v])=>{ const el=$(`input[name="${k}"][value="${CSS.escape(v)}"]`); if(el) el.checked=true; });
   Object.entries(state.checks).forEach(([g,vals])=>Object.entries(vals).forEach(([v,on])=>{ const el=$(`#c_${CSS.escape(g)}_${CSS.escape(v)}`); if(el) el.checked=!!on; }));
 }catch(e){}
}
function aboutMe(){ $('#aboutModal').style.display='flex'; }
function closeAbout(){ $('#aboutModal').style.display='none'; }
function filterQuestions(){ const q=$('#search').value.trim().toLowerCase(); $$('.qblock').forEach(b=>b.style.display=!q||b.dataset.text.includes(q)?'block':'none'); }
window.addEventListener('DOMContentLoaded',()=>{buildQuestions(); $('#eval').onclick=evaluate; $('#reset').onclick=resetAll; $('#distros').onclick=showDistros; $('#saveTxt').onclick=()=>saveResult('txt'); $('#saveJson').onclick=()=>saveResult('json'); $('#about').onclick=aboutMe; $('#closeAbout').onclick=closeAbout; $('#search').oninput=filterQuestions;});
